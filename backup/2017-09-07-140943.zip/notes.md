#### Notes for fire pulse analysis
1. first cut at looking at the data
 - read one of the data files and plot the data, use other files as a starter
 - process like the CVR data from Claire
2. goals of the analysis
 - rise time and peak current flow
 - overlay CVR fire pulse with LEEFI fire pulse and compare rise time and peak values

***
#### Current Viewing Resistor Analysis

