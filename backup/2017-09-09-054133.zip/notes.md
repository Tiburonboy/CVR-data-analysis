#### Notes for fire pulse analysis
1. first cut at looking at the data
 - read one of the data files and plot the data, use other files as a starter
 - process like the CVR data from Claire
2. goals of the analysis
 - rise time and peak current flow
 - overlay CVR fire pulse with LEEFI fire pulse and compare rise time and peak values

***
#### Current Viewing Resistor Analysis
- Show that the fire pulse wave forms from the Neyer test into actual LEEFI and ring down are similar to the CVR.
- show the plots over laid, data need to be normalized and time aligned for plotting
    - 1000V ring down, looking for a 800V ring down
    - TEST1 800V fire
    - FTSA into CVR fire pulse
- 
